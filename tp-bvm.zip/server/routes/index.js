module.exports = (router) => {
  require('./dashboard')(router)
}
