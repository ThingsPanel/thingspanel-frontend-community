export default [
    {
          name: 'Theme1',
          // bgcolor: '#18309e',
          bgcolor: '#000000',
    },
    {
          name: 'Theme2',
          bgcolor: '#2d3d88',
    },
    {
          name: 'Theme3',
          bgcolor: '#3046a9',
    },
    {
        name:'Theme4',
        bgcolor:'#ffffff',
    }
  ];
