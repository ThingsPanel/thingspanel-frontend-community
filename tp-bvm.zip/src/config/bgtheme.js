export default [
  {
    name: "蓝色背景",
    bgcolor: "#1f2a5e"
  },
  {
    name: "白色背景",
    bgcolor: "rgba(247, 247, 247, 0.99)"
  }
];
