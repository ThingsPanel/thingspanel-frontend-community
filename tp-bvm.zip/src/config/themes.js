export default [
  {
    name: 'Theme1',
    colorStart: '#7956EC',
    colorEnd: '#2FB9F8',
  },
  {
    name: 'Theme2',
    colorStart: '#F23673',
    colorEnd: '#FFC066',
  },
  {
    name: 'Theme3',
    colorStart: '#009FC5',
    colorEnd: '#3CECB0',
  },
  {
    name: 'Theme4',
    colorStart: '#5134B2',
    colorEnd: '#B175EB',
  },
];
