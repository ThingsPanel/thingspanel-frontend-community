export { default as CanvasRenderer } from './CanvasRenderer.vue'
