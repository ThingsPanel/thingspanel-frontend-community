<!-- src/components/visual-editor/settings/components/TextWidgetSettings.vue -->
<template>
  <div class="text-widget-settings">
    <p>这里是文本组件的专有配置。</p>
    <!-- 后续实现: 文本内容, 字体大小, 颜色等 -->
  </div>
</template>

<script setup lang="ts">
// Props and logic will be added here
</script>
