<!-- src/components/visual-editor/settings/components/BaseSettingsForm.vue -->
<template>
  <div class="base-settings-form">
    <p>这里是基础配置表单。</p>
    <!-- 后续实现: 名称, 宽高, 位置等表单项 -->
  </div>
</template>

<script setup lang="ts">
// Props 和逻辑将在这里添加
</script>
