<!-- src/components/visual-editor/settings/data/DeviceDataSourceForm.vue -->
<template>
  <div class="device-data-source-form">
    <p>这里是设备数据源配置表单。</p>
    <!-- 后续实现: 设备选择器 -->
  </div>
</template>

<script setup lang="ts">
// Props and logic will be added here
</script>
