<!-- src/components/visual-editor/settings/data/DataSourceSelector.vue -->
<template>
  <div class="data-source-selector">
    <p>这里是数据源选择器。</p>
    <!-- 后续实现: 数据源类型切换 (JSON / 设备) -->
    <!-- 并根据类型动态渲染下面的表单 -->
  </div>
</template>

<script setup lang="ts">
// Props and logic will be added here
</script>
