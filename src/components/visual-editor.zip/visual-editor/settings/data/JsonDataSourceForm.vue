<!-- src/components/visual-editor/settings/data/JsonDataSourceForm.vue -->
<template>
  <div class="json-data-source-form">
    <p>这里是 JSON 数据源配置表单。</p>
    <!-- 后续实现: JSON 编辑器 -->
  </div>
</template>

<script setup lang="ts">
// Props and logic will be added here
</script>
